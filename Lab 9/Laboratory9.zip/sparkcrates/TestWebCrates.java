package sparkcrates;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Map;
import java.util.List;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Test;
import static org.junit.Assert.*;

import spark.Spark;
import spark.utils.IOUtils;

/**
 * 
 * @author jsinger
 *
 */
public class TestWebCrates {

    private static final int PORT = 4567;

    @BeforeClass
    public static void beforeClass() {
        // initialize spark framework
        // running WebCrates system
        WebCrates.main(null);
        try {
            // wait 1s for spark framework to boot up...
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            System.err.println("interrupted!");
        }
    }

    @AfterClass
    public static void afterClass() {
        // shutdown Spark framework properly
        Spark.stop();
    }

    /**
     * A simple example test - follow this structure
     * for your own tests... 
     * This one checks
     * http://localhost:4567/showcrates returns a non-empty response
     */
    @Test
    public void testShowCrates() {
        UrlResponse response = doMethod("GET", "/showcrates", null);
        assertEquals(200, response.status);
        assertTrue("empty response body", response.body.length() > 0);
    }

    /**
     * Helper methods/classes follow...
     */
    private static UrlResponse doMethod(String requestMethod, String path,
            String body) {
        UrlResponse response = new UrlResponse();
        try {
            getResponse(requestMethod, path, response);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return response;
    }

    private static void getResponse(String requestMethod, String path,
            UrlResponse response) throws MalformedURLException, IOException,
            ProtocolException {
        URL url = new URL("http://0.0.0.0:" + PORT + path);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod(requestMethod);
        connection.connect();
        String res = IOUtils.toString(connection.getInputStream());
        response.body = res;
        response.status = connection.getResponseCode();
        response.headers = connection.getHeaderFields();
    }

    private static class UrlResponse {
        public Map<String, List<String>> headers;
        private String body;
        private int status;
    }

}
