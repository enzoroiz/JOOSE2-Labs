package sparkcrates;

import java.util.ArrayList;
import java.util.List;

import fillingcrates.FillableContainer;

import static spark.Spark.*;
import spark.Route;
import spark.Request;
import spark.Response;
import spark.Spark;

/**
 * Submission for Java labs 9+10
 * Student to fill in details...
 */
public class WebCrates {

    /**
     * the internal state of the web application - 
     * the list of crates that we are going to
     * organize using a predefined fitting algorithm.
     * NOTE - this List corresponds to the 'model'
     * in an MVC style design pattern.
     */
    public static List<FillableContainer> crates;

    static {
        crates = new ArrayList<FillableContainer>();
    }

    public static void main(String[] args) {
        
         // put your get Spark callbacks here...
    }
}
