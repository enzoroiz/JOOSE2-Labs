/**
 * subclass of {@link BankAccount} that
 * keeps track of the most recent 
 * {@link Transaction} on this account
 * @author YOURNAMEHERE
 */
public class TransactionalBankAccount extends BankAccount {

    // instance fields

    // Constructor

    // methods

    @Override
    public String toString() {
        String s = super.toString();
        return s;
    }

}