/**
 * represents a single transaction
 * on a single bank account
 * @see TransactionalBankAccount
 * @author jsinger
 */
public abstract class Transaction {

    // instance fields

    // constructor

    // methods
    public abstract boolean apply(TransactionalBankAccount account);
}