/**
 * @author jsinger - REPLACE!
 * Assessed submission for Java lab 3
 * This class represents a simple bank account
 */
public class BankAccount {
    
    // instance fields

    /**
     * each BankAccount instance should have
     * a unique account number
     */
    private int accountNumber;

    // static fields


    // accessor methods

    public int getAccountNumber() {
        return this.accountNumber;
    }

    // constructors
    
    // other methods

}
