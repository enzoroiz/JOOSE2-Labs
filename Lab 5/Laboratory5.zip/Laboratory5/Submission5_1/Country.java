import java.util.ArrayList;

/**
 * Represents a country.
 * This class should be completed by the student.
 * @author jsinger
 */
public class Country {

    public Country(String name) {
    }

    public static ArrayList<Country> getCountries() {
        return null;
    }

}
