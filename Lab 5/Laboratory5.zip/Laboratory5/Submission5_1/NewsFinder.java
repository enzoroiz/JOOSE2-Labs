import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;

/**
 * Reads the news from a supplied URL and caches the content, ready for searches.
 * This class should be completed by the student.
 * @author jsinger 
 */
public class NewsFinder {
    
    public NewsFinder(String url) {
    }
    
    public boolean isInNews(Object o) {
        return false;
    }

}
